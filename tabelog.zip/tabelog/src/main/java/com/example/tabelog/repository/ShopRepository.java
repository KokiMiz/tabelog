package com.example.tabelog.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.tabelog.entity.Shop;

public interface ShopRepository extends JpaRepository<Shop, Integer> {
    // 必要に応じてカスタムメソッドを追加できます
}

