package com.example.tabelog.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.tabelog.entity.Favorite;

public interface FavoriteRepository extends JpaRepository<Favorite, Integer> {
    // 必要に応じてカスタムメソッドを追加できます
}
