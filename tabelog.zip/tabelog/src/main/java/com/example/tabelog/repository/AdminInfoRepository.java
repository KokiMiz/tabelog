package com.example.tabelog.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.tabelog.entity.AdminInfo;

public interface AdminInfoRepository extends JpaRepository<AdminInfo, Integer> {
    // 必要に応じてカスタムメソッドを追加できます
}