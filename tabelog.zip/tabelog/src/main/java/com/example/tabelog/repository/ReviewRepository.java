package com.example.tabelog.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.tabelog.entity.Review;

public interface ReviewRepository extends JpaRepository<Review, Integer> {
    // 必要に応じてカスタムメソッドを追加できます
}

