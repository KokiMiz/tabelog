package com.example.tabelog.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.tabelog.entity.Category;

public interface CategoryRepository extends JpaRepository<Category, Integer> {
    public Page<Category> findByNameLike(String keyword, Pageable pageable);
    
    public Page<Category> findByNameLikeOrAddressLikeOrderByCreatedAtDesc(String nameKeyword, String addressKeyword, Pageable pageable);  
    public Page<Category> findByNameLikeOrAddressLikeOrderByPriceAsc(String nameKeyword, String addressKeyword, Pageable pageable);  
    public Page<Category> findByAddressLikeOrderByCreatedAtDesc(String area, Pageable pageable);
    public Page<Category> findByAddressLikeOrderByPriceAsc(String area, Pageable pageable);
    public Page<Category> findByPriceLessThanEqualOrderByCreatedAtDesc(Integer price, Pageable pageable);
    public Page<Category> findByPriceLessThanEqualOrderByPriceAsc(Integer price, Pageable pageable); 
    public Page<Category> findAllByOrderByCreatedAtDesc(Pageable pageable);
    public Page<Category> findAllByOrderByPriceAsc(Pageable pageable);  
    
    public List<Category> findTop10ByOrderByCreatedAtDesc();
}