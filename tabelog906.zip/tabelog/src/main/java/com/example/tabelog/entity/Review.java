package com.example.tabelog.entity;

public class Review {

}
