package com.example.tabelog.repository;

public interface ReviewRepository {

}
