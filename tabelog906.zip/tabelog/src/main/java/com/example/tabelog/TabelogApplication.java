package com.example.tabelog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TabelogApplication {

	public static void main(String[] args) {
		SpringApplication.run(TabelogApplication.class, args);
	}

}
