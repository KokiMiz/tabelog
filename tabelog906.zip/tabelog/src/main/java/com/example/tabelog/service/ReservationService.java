package com.example.tabelog.service;

import java.time.LocalDate;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.tabelog.entity.Reservation;
import com.example.tabelog.entity.Shop;
import com.example.tabelog.entity.User;
import com.example.tabelog.form.ReservationRegisterForm;
import com.example.tabelog.repository.ReservationRepository;
import com.example.tabelog.repository.ShopRepository;
import com.example.tabelog.repository.UserRepository;

@Service
public class ReservationService {
	
	private final ReservationRepository reservationRepository;  
	private final ShopRepository shopRepository;  
	private final UserRepository userRepository;  

	public ReservationService(ReservationRepository reservationRepository, ShopRepository shopRepository, UserRepository userRepository) {
	    this.reservationRepository = reservationRepository;  
	    this.shopRepository = shopRepository;  
	    this.userRepository = userRepository;  
	}    

	@Transactional
	public void create(ReservationRegisterForm reservationRegisterForm) { 
	    Reservation reservation = new Reservation();
	    Shop shop = shopRepository.getReferenceById(reservationRegisterForm.getShopId());
	    User user = userRepository.getReferenceById(reservationRegisterForm.getUserId());
	    LocalDate reservationDate = LocalDate.parse(reservationRegisterForm.getReservationDate());
	             
	    reservation.setShop(shop);
	    reservation.setUser(user);
	    reservation.setReservationDatetime(reservationDate.atStartOfDay());
	    reservation.setNumberOfPeople(reservationRegisterForm.getNumberOfPeople());
	    reservation.setAmount(reservationRegisterForm.getAmount());
	    
	    reservationRepository.save(reservation);
	}

    // 人数に基づいて料金を計算する
    public Integer calculateAmount(LocalDate reservationDate, Integer pricePerPerson, Integer numberOfPeople) {
        // 人数に基づいて料金を計算
        int amount = pricePerPerson * numberOfPeople;
        return amount;
    }
}
